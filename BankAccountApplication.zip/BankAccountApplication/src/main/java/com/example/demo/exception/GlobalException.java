package com.example.demo.exception;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import com.example.demo.dto.ErrorDetails;

@ControllerAdvice
public class GlobalException {
	
	@ExceptionHandler(CustomerNotFoundException.class)
	public ResponseEntity<ErrorDetails> handleCustomerNotFoundException(CustomerNotFoundException ex, WebRequest request){
		return new ResponseEntity<ErrorDetails>(new ErrorDetails(new Date(),ex.getMessage(),request.getDescription(false)), HttpStatus.NOT_FOUND);
	}

}
