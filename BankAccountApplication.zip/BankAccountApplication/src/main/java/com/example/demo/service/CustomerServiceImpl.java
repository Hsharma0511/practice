package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Customer;
import com.example.demo.exception.CustomerNotFoundException;
import com.example.demo.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	CustomerRepository customerRepository;

	@Override
	public List<Customer> getAllCustomers() {
		return customerRepository.findAll();
	}
	
	public Customer createCustomer(Customer customer) {
		return customerRepository.save(customer);
	}

	@Override
	public List<Customer> createListOfCustomers(List<Customer> customer) {
		return customerRepository.saveAll(customer);
	}

	@Override
	public Customer getCustomerById(int cId) throws CustomerNotFoundException{
		// TODO Auto-generated method stub
		if(customerRepository.findById(cId).isEmpty())
			throw new CustomerNotFoundException("No customer found with id :"+cId);
		else
			return customerRepository.findById(cId).get();
	}


}
