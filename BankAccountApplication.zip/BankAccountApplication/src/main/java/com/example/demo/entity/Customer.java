package com.example.demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(name="CUSTOMER")
public class Customer {
	@Id
	@Column(name="CUSTOMER_ID")
	private int accId;
	
	@Column(name="FIRST_NAME")
	@NotNull(message="Customer name cannot be null")
	@NotEmpty(message="Customer name cannot be empty")
	@Size(min=3, max=10, message="First name length should be 3 to 10")
	private String firstName;
	
	@Column(name="LAST_NAME")
	@Size(min=3, max=10, message="Last name length should be 3 to 10")
	private String lastName;
	
	@Column(name="EMAIL")
	private String email;
	
	@Column(name="PHONE_NO")
	private String phoneNo;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public int getAccId() {
		return accId;
	}

	public void setAccId(int accId) {
		this.accId = accId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Customer(int accId, String firstName, String lastName,String email, String phoneNo) {
		this.accId = accId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email=email;
		this.phoneNo=phoneNo;
	}
	
	public Customer() {
		
	}
	

}
