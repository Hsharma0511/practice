package com.example.demo.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="TRANSACTION")
public class Transaction {
	@Id
	@Column(name="TRANSACION_ID")
	private int tId;
	
	@Column(name="TIME")
	private LocalDateTime transactionTime;
	
	@Column(name="CURRENT_BALANCE")
	private double currentBalance;
	
	@Column(name="TYPE_OF_TRANSACTION")
	private String typeOfTransaction;
	
	@Column(name="BAL_AFTER_TRANSACTION")
	private double balAfterTransaction;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="ACCOUNT_NO")
	private Account account;

	public int gettId() {
		return tId;
	}

	public void settId(int tId) {
		this.tId = tId;
	}

	public LocalDateTime getTransactionTime() {
		return transactionTime;
	}

	public void setTransactionTime(LocalDateTime transactionTime) {
		this.transactionTime = transactionTime;
	}

	public double getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(double currentBalance) {
		this.currentBalance = currentBalance;
	}

	public String getTypeOfTransaction() {
		return typeOfTransaction;
	}

	public void setTypeOfTransaction(String typeOfTransaction) {
		this.typeOfTransaction = typeOfTransaction;
	}

	public double getBalAfterTransaction() {
		return balAfterTransaction;
	}

	public void setBalAfterTransaction(double balAfterTransaction) {
		this.balAfterTransaction = balAfterTransaction;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public Transaction(int tId, LocalDateTime transactionTime, double currentBalance, String typeOfTransaction,
			double balAfterTransaction) {
		super();
		this.tId = tId;
		this.transactionTime = transactionTime;
		this.currentBalance = currentBalance;
		this.typeOfTransaction = typeOfTransaction;
		this.balAfterTransaction = balAfterTransaction;
	}
	
	public Transaction() {
		
	}
	
}

 