package com.example.demo.entity;

import java.sql.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="Orders")
public class Orders {
	@Id
	@Column(name="ORDER_ID")
	private int orderId;
	
	@Column(name="DATE_OF_ORDER")
	private Date dateOfOrder;
	
	@Column(name="TOTAL_AMOUNT")
	private Long totalAmount;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="CUSTOMER_ID")
	Customer customer;
	
	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@ManyToMany
	@JoinTable(name="PRODUCT_ORDERD",joinColumns = @JoinColumn(name="orderId"), inverseJoinColumns = @JoinColumn(name="PRODUCT_ID"))
	private List<Products> product;
	

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public List<Products> getProduct() {
		return product;
	}

	public void setProduct(List<Products> product) {
		this.product = product;
	}
	
	public Date getDateOfOrder() {
		return dateOfOrder;
	}

	public void setDateOfOrder(Date dateOfOrder) {
		this.dateOfOrder = dateOfOrder;
	}

	public Long getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Long totalAmount) {
		this.totalAmount = totalAmount;
	}

	public Orders(int orderId, Date dateOfOrder, Long totalAmount) {
		super();
		this.orderId = orderId;
		this.dateOfOrder = dateOfOrder;
		this.totalAmount = totalAmount;
	}
	
	
	
}
