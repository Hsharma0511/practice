		package com.example.demo.entity;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="CUSTOMER")
public class Customer {
	@Id
	@Column(name="CUSTOMER_ID")
	private int cId;
	
	@Column(name="NAME")
	private String cName;
	
	@Column(name="EMAIL")
	private String cEmail;

	@OneToMany(mappedBy = "customer" , cascade = CascadeType.ALL, orphanRemoval = true) 
	List<Orders> orders;
	
	public int getcId() {
		return cId;
	}

	public void setcId(int cId) {
		this.cId = cId;
	}

	public String getcEmail() {
		return cEmail;
	}

	public void setcEmail(String cEmail) {
		this.cEmail = cEmail;
	}

	public String getcName() {
		return cName;
	}

	public void setcName(String cName) {
		this.cName = cName;
	}

	public Customer(int cId, String cName, String cEmail) {
		super();
		this.cId = cId;
		this.cName = cName;
		this.cEmail = cEmail;
	}

	@Override
	public String toString() {
		return "Customer [cId=" + cId + ", cName=" + cName + ", cEmail=" + cEmail + "]";
	}

	public List<Orders> getOrders() {
		return orders;
	}

	public void setOrders(List<Orders> orders) {
		this.orders = orders;
	}
	
	
	
	
	
}
