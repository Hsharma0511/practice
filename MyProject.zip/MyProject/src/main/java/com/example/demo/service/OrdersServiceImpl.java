package com.example.demo.service;

public class OrdersServiceImpl implements OrdersService {

}
