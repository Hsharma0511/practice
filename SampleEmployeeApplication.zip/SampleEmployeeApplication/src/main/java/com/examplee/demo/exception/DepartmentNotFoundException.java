package com.examplee.demo.exception;

public class DepartmentNotFoundException  extends Exception {
	private String message;
	public DepartmentNotFoundException(String message) {
		this.message=message;
	}
	
	public String getMessage() {
	return this.message;
	}
}
