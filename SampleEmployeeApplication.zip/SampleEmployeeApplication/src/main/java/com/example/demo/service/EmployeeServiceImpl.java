package com.example.demo.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.MaxSalDepartment;
import com.example.demo.entity.Employee;
import com.example.demo.repository.EmployeeRepository;
import com.examplee.demo.exception.EmployeeNotFoundException;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	@Autowired
	EmployeeRepository employeeRepo;
	
	@Override
	public List<Employee> getAllEmployees(){
		return employeeRepo.findAll();
	}

	@Override
	public Employee getAllEmployeeById(int id) throws EmployeeNotFoundException {
		if(employeeRepo.findById(id).isEmpty()) {
			throw new EmployeeNotFoundException("Not Found");
		}
		else {
			Employee emp=employeeRepo.findById(id).get();
			return emp;
		}
	}

	@Override
	public Employee deleteEmployeeById(int id) throws EmployeeNotFoundException {
		if(employeeRepo.findById(id).isEmpty()) {
			throw new EmployeeNotFoundException("Not Found Employee Id");
		}
		else {
			Employee emp=employeeRepo.findById(id).get();
			employeeRepo.deleteById(id);
			return emp;
		}
	}

	@Override
	public Employee createEmployee(Employee emp) throws EmployeeNotFoundException {
		employeeRepo.save(emp);
		return emp;
	}

	@Override
	public Employee updateEmployee(Employee emp) throws EmployeeNotFoundException {
		if(employeeRepo.findById(emp.getId()).isEmpty()) {
			throw new EmployeeNotFoundException("Not Found Employee");
		}
		else {
			employeeRepo.save(emp);
			return emp;
		}
	}

	@Override
	public List<Employee> getEmployeeCountByDesignation(String designation){
//		Map<String, Long> m1=new HashMap<>();
		return employeeRepo.findAll().stream().filter(e->e.getDesignation().equals(designation)).collect(Collectors.toList());
//		employeeRepo.getEmployeeCountByDesignation()
	}

	@Override
	public List<Employee> getEmployeeWithHighestSalary() {
		return employeeRepo.getEmployeeWithHighestSalary();
	}
	
//	@Override
//	public Map<String,String> getNameAndDepartment(){
//		Map<String,String> res=new HashMap<>();
//		employeeRepo.getNameAndDepartment().stream().forEach(obj->res.put((String)obj[0], (String)obj[1]));
//		return res;
//	}

	@Override
	public List<MaxSalDepartment> getMaxSalaryByDepartment() {
		List<MaxSalDepartment> res= new ArrayList<>();
		employeeRepo.getMaxSalaryByDepartment().stream().forEach(obj->res.add(new MaxSalDepartment((int)obj[0],(String)obj[1])));
		
		return res;
	}

	@Override
	public int getAllSalaryDescendingOrder(int n) {
		return employeeRepo.getAllSalaryDescendingOrder().get(n).getSal();
	}
	
	
}
