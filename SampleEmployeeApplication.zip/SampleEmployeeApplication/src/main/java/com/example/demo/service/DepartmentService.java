package com.example.demo.service;

import java.util.List;
import java.util.Map;

import com.example.demo.entity.Department;
import com.examplee.demo.exception.DepartmentNotFoundException;

public interface DepartmentService {
	List<Department> getAllDepartments();
	
	Department getAllDepartmentById(int id) throws DepartmentNotFoundException;
	
	void deleteDepartmentById(int id) throws DepartmentNotFoundException;
	
	Department createDepartment(Department emp) throws DepartmentNotFoundException;
	
	Department updateDepartment(Department emp) throws DepartmentNotFoundException;
}
