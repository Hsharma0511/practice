package com.example.demo.dto;

public class MaxSalDepartment {
	private int maxSalary;
	
	private String department;

	public MaxSalDepartment() {
		
	}
	
	public MaxSalDepartment(int maxSalary, String department) {
		super();
		this.maxSalary = maxSalary;
		this.department = department;
	}

	public long getMaxSalary() {
		return maxSalary;
	}

	public void setMaxSalary(int maxSalary) {
		this.maxSalary = maxSalary;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	@Override
	public String toString() {
		return "MaxSalDepartment [maxSalary=" + maxSalary + ", department=" + department + "]";
	}
	
}
