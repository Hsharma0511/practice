package com.example.demo.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Department;
import com.example.demo.repository.DepartmentRepository;
import com.examplee.demo.exception.DepartmentNotFoundException;

@Service
public class DepartmentServiceImpl implements DepartmentService{

	@Autowired
	DepartmentRepository deptRepo;
	
	@Override
	public List<Department> getAllDepartments() {
		return deptRepo.findAll();
	}

	@Override
	public Department getAllDepartmentById(int id) throws DepartmentNotFoundException {
		if(deptRepo.findById(id).isEmpty()) {
			throw new DepartmentNotFoundException("Department Not Found");
		}
		else {
			return deptRepo.findById(id).get();
		}
	}

	@Override
	public void deleteDepartmentById(int id) throws DepartmentNotFoundException {
		if(deptRepo.findById(id).isEmpty()) {
			throw new DepartmentNotFoundException("Department Not Found");
		}
		else {
			deptRepo.deleteById(id);
		}
	}

	@Override
	public Department createDepartment(Department dep) throws DepartmentNotFoundException {
		return deptRepo.save(dep);
	}

	@Override
	public Department updateDepartment(Department dep) throws DepartmentNotFoundException {
		return deptRepo.save(dep);
	}

}
