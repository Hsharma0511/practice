package com.example.demo.dto;

public class EmployeeDepartment {
	private String employeeName;
	private String deptName;
	
	public String getEmployeeName() {
		return employeeName;
	}
	
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	
	public String getDeptName() {
		return deptName;
	}
	
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	
	public EmployeeDepartment() {
	}
	
	public EmployeeDepartment(String employeeName, String deptName) {
		super();
		this.employeeName = employeeName;
		this.deptName = deptName;
	}
}
