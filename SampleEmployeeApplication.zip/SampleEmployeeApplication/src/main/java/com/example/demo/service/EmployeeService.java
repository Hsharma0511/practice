package com.example.demo.service;

import java.util.List;
import java.util.Map;

import com.example.demo.dto.MaxSalDepartment;
import com.example.demo.entity.Employee;
import com.examplee.demo.exception.EmployeeNotFoundException;

public interface EmployeeService {
	List<Employee> getAllEmployees();
	
	Employee getAllEmployeeById(int id) throws EmployeeNotFoundException;
	
	Employee deleteEmployeeById(int id) throws EmployeeNotFoundException;
	
	Employee createEmployee(Employee emp) throws EmployeeNotFoundException;
	
	Employee updateEmployee(Employee emp) throws EmployeeNotFoundException;
	
	List<Employee> getEmployeeCountByDesignation(String designation);
	
	List<Employee> getEmployeeWithHighestSalary();
	
//	Map<Object[]> getNameAndDepartment();
	
	List<MaxSalDepartment> getMaxSalaryByDepartment();
	
	int getAllSalaryDescendingOrder(int n);
}
