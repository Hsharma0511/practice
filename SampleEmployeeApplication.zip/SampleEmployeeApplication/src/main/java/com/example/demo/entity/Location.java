package com.example.demo.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity

public class Location {
	
	@Id
	@Column(name="LOC_ID")
	private int locId;
	
	@Column(name="LOC_NAME")
	private String locName;
	
	@OneToMany(mappedBy = "location", cascade=CascadeType.ALL, orphanRemoval = true)
	@JsonManagedReference
	private List<Department> dep;
	
	public int getLocId() {
		return locId;
	}
	
	public void setLocId(int locId) {
		this.locId = locId;
	}
	
	public String getLocName() {
		return locName;
	}
	
	public void setLocName(String locName) {
		this.locName = locName;
	}
	
	
}
