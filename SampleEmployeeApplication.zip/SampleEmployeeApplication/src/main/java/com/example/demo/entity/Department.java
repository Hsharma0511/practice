package com.example.demo.entity;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="DEPT")
public class Department {
	
	@Id
	@Column(name="DEPT_ID")
	private int dptId;
	
	@Column(name="DEPT_NAME")
	private String deptName;
	
//	@Column(name="LOC_NAME")
//	private String city;
	
	
	@OneToMany(mappedBy="department", cascade=CascadeType.ALL, orphanRemoval = true)
	private List<Employee> employees;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="LOC_ID")
	private Location location;

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public Department(int dptId, String deptName, String city) {
		super();
		this.dptId = dptId;
		this.deptName = deptName;
//		this.city = city;
	}
	
	public Department() {
	}

	public int getDptId() {
		return dptId;
	}

	public void setDptId(int dptId) {
		this.dptId = dptId;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

//	public String getCity() {
//		return city;
//	}

//	public void setCity(String city) {
//		this.city = city;
//	}
	
    public List<Employee> getEmployees() {
    	return employees;
    }
	
	
	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}
}
