package com.example.demo;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.entity.Employee;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.service.DepartmentService;
import com.example.demo.service.EmployeeService;
import com.examplee.demo.exception.DepartmentNotFoundException;
import com.examplee.demo.exception.EmployeeNotFoundException;

@SpringBootApplication
public class SampleEmployeeApplication implements CommandLineRunner{

	@Autowired
	EmployeeService services;
	
	@Autowired
	DepartmentService depServices;
	
	public static void main(String[] args) {
		SpringApplication.run(SampleEmployeeApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
//		services.getAllEmployees().stream().forEach(e->System.out.println(e));
		
		
//		try {
//			System.out.println(services.getAllEmployeeById(1));
//			System.out.println(services.deleteEmployeeById(5));
//			Employee emp=new Employee(0, null, 0,null);
//			emp.setDepartment();
//			System.out.println(services.createEmployee(new Employee(12, "Harsh", 40000)));
//			System.out.println(services.updateEmployee(new Employee(12, "Harsh", 80000,"Trainer")));
//			for(Map.Entry<String, Long> map:services.getEmployeeCountByDesignation().entrySet()) {
//				System.out.println(map.getKey()+" "+map.getValue());
//			}
			
//			Employee emp=services.getAllEmployeeById(12);
//			emp.setDepartment(depServices.getAllDepartmentById(10));
//			System.out.println(services.updateEmployee(emp));
//			services.getEmployeeWithHighestSalary().stream().forEach(o->System.out.println(o));;
//			
//			for(Map.Entry<String, String> map:services.getNameAndDepartment().entrySet()) {
//				System.out.println(map.getKey()+" "+map.getValue());
//			}
		
		System.out.println(services.getMaxSalaryByDepartment());;
			
//		}catch (EmployeeNotFoundException e) {
//			System.out.println(e.getMessage());
//		}catch (DepartmentNotFoundException e) {
//			System.out.println(e.getMessage());
//		}
	}

}
