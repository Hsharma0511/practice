package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Employee;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer>{
	
	@Query("select e.designation, count(e.id) from Employee e group by e.designation")
	List<Object[]> getEmployeeCountByDesignation();
	
	@Query("select e from Employee e where e.sal=(select max(d.sal) from Employee d)")
	List<Employee> getEmployeeWithHighestSalary();
	
	@Query("select e.name, e.department.deptName from Employee e")
	List<Object[]> getNameAndDepartment();
	
	@Query("select max(e.sal), e.department.deptName from Employee e group by e.department.deptName")
	List<Object[]> getMaxSalaryByDepartment();
	
//	@Query(nativeQuery=true,value="select salary from employee order by salary desc limit:n,1")
//	List<Integer> getNthHighestSalary(@Param("n") int n);
	
	@Query("select e from Employee e order by e.sal desc")
	List<Employee> getAllSalaryDescendingOrder();
	
	@Query(value="select e from Employee e where e.department.locationName=:locationName")
	List<Employee> getEmployeesByLocationName(String locationName);
}
